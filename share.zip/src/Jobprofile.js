const JobProfile=({pos,ctc})=>{
    return(<>
        <div>
        
          <p>position : {pos}</p>
          <p><strong>CTC :</strong> ${ctc}</p>

       </div>   
    
    </>)
}
export default JobProfile;
