import React from "react";

const Services=() =>{
    return(
        <>
        <section class="p-2" style={{height: '30vh'}}>
        <div class="container-fluid bg-info">
            <div class="row">
                <div class="col-lg-12 text-center lg-3">
                <h1 class="text-warning display-1">How to learn React!</h1>
                <p class="lead text-primay"> Install NPM. NPM Node Package Manager is a site that allows you to install libraries into your React project. ...
Choose an IDE. IDEs are the development environments in which developers build applications. ...
Use Prettier. Your React code can become messy quickly. ...
Try out create-react-app. </p>
                </div>
                </div>
       
              </div>
    </section>
        </>
    )
}

export default Services;