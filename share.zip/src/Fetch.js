import  { useEffect, useState } from "react";

const Fetch = () => {
  const [data, setData] = useState([]);
  
  useEffect(() => {
    fetch("../blogdatas.json")
      .then(res => res.json())
      .then(res => setData(res.items))
      .catch(err => console.log(err));
  }, []);

  return (
    <>
     {
        data && data.map(post=><p>{post.title}</p>)
     }
    </>
  );
};

export default Fetch;
