const Location=({loc}) =>{
    return(
        <>
        <div>
            
            <p><b>Location</b> : {loc}</p>
        </div>
        </>
    )
}
export default Location ;