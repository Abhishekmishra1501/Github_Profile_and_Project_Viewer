const About = () =>{
   return(
    <>
       <h1 style={{textAlign:'center',backgroundColor:'lightgray'}}>About Us</h1>
       <p>  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ducimus quas fugit, praesentium, illum, earum deleniti odit ipsa minus nemo itaque perspiciatis quae sint doloremque labore perferendis excepturi in? Doloribus, nobis.  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ducimus quas fugit, praesentium, illum, earum deleniti odit ipsa minus nemo itaque perspiciatis quae sint doloremque labore perferendis excepturi in? Doloribus, nobis.  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ducimus quas fugit, praesentium, illum, earum deleniti odit ipsa minus nemo itaque perspiciatis quae sint doloremque labore perferendis excepturi in? Doloribus, nobis.  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ducimus quas fugit, praesentium, illum, earum deleniti odit ipsa minus nemo itaque perspiciatis quae sint doloremque labore perferendis excepturi in? Doloribus, nobis.  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ducimus quas fugit, praesentium, illum, earum deleniti odit ipsa minus nemo itaque perspiciatis quae sint doloremque labore perferendis excepturi in? Doloribus, nobis.  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ducimus quas fugit, praesentium, illum, earum deleniti odit ipsa minus nemo itaque perspiciatis quae sint doloremque labore perferendis excepturi in? Doloribus, nobis.  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ducimus quas fugit, praesentium, illum, earum deleniti odit ipsa minus nemo itaque perspiciatis quae sint doloremque labore perferendis excepturi in? Doloribus, nobis.</p>
    </>
   )
}

export default About;