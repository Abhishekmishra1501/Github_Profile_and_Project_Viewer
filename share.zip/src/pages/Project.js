// import { useState,useEffect } from "react";
import "./project.css";
const FunctionalFetchApi= ({data})=>{
  

return (
        <>
            {data && (
                <>
                <div><img src="https://avatars.githubusercontent.com/u/583231?v=4" style ={{width:190,padding:'20px'}}></img><br/><h3 style={{fontSize:'25px'}}>Profile</h3></div>
               <div style ={{float:'left',marginLeft:'80px',fontWeight:'bold',textAlign:'left'}}>html_url:<br/>
               repos_url:<br/>
               name:<br/>
               company:<br/>
               location:<br/>
               email:<br/>
               bio:<br/>
               
               </div>
               
                <div style={{float:'right',marginRight:'80px',textAlign:'right'}}>
                    <a href ={data.html_url}>{data.html_url}</a><br/>
                    <a href ={data.repos_url}>{data.repos_url}</a><br/>
                    {data.name}<br/>
                    {data.company}<br/>
                    {data.location}<br/>
                    not found<br/>
                    not found<br/>
                
                    </div>
                     
                </>
            )}
            
          
            
            
        </>
       
    );
}
export default FunctionalFetchApi;